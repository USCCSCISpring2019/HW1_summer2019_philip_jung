package philipju_CSCI201L_Assignment1;
import java.util.ArrayList; // needed for ArrayList class
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		ArrayList<City> cityList = new ArrayList<City>();
		Scanner keyboard = new Scanner(System.in);
		String fileName;
		
		do {
			cityList.clear();
			System.out.print("What is the name of the weather file? ");
			fileName = keyboard.nextLine();
			System.out.println("");
		} while (!ReadFile.read(cityList, fileName));
		
		Menu app = new Menu(cityList);
		app.run();
		keyboard.close();
	}
}
		
		/*
		System.out.print("What is the name of the weather file? ");
		fileName = keyboard.nextLine();
		System.out.println("");
		// attempt to open the file
		try {
			File file = new File(fileName);
			Scanner inputFile = new Scanner(file);
			// if file found, continue execution of code here
			while (inputFile.hasNext()) {
				String text = inputFile.nextLine();
				String[] cityInfo = text.split("\\|");
				

				if (cityInfo.length < 10) {
					// Needs at least 10 categories
					// Print out error message
					System.out.print("There are not enough parameters on line ");
					System.out.print("'" + text + "'.");
					break;
				}
				
				// Will store a list of cities in ArrayList so we can
				//   dynamically change the size of it (adding).
				
				try {
					City nextCity = new City(cityInfo);
					// if we are able to create this new city, continue execution of code here
					cityList.add(nextCity);
				}
				catch (MyException e) {
					// Print out error message
					System.out.println("This file " + fileName + " is not formatted properly.");
					System.out.print(e.getMessage());
					break;
				}
			}
			
			inputFile.close();
			Menu app = new Menu(cityList);
			app.run();
			
		} 
		catch (FileNotFoundException e) {
			System.out.println("The file " + fileName + " could not be found.");
		}
		keyboard.close();
	*/
