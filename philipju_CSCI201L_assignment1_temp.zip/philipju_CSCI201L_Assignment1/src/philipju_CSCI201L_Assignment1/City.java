package philipju_CSCI201L_Assignment1;
import java.lang.NumberFormatException; // needed for NumberFormatException class
public class City  {
	private String city;
	private int currentTemperature;
	private int dayLow;
	private int dayHigh;
	private int humidity;
	private float pressure;
	private float visibility;
	private float windspeed;
	private int windDirection;
	private String[] conditionDescription;
	
	
	// Constructor that takes an array of Strings as arg
	City(String[] cityInfo) throws MyException {
		city = cityInfo[0];
		currentTemperature = myIntParser(cityInfo[1]);
		dayLow = myIntParser(cityInfo[2]);
		dayHigh = myIntParser(cityInfo[3]);
		humidity = myIntParser(cityInfo[4]);
		pressure = myFloatParser(cityInfo[5]);
		visibility = myFloatParser(cityInfo[6]);
		windspeed = myFloatParser(cityInfo[7]);
		windDirection = myIntParser(cityInfo[8]);
		conditionDescription = new String[ cityInfo.length - 9 ];
		for (int i = 9; i < cityInfo.length; i++) {
			conditionDescription[i - 9] = myDescriptionParser(cityInfo[i]);
		}
	}
	public String getCity() {
		return city;
	}
	public int getCurrentTemperature() {
		return currentTemperature;
	}
	public int getDayLow() {
		return dayLow;
	}
	public int getDayHigh() {
		return dayHigh;
	}
	public int getHumidity() {
		return humidity;
	}
	public float getPressure() {
		return pressure;
	}
	public float getVisibility() {
		return visibility;
	}
	public float getWindspeed() {
		return windspeed;
	}
	public int getWindDirection() {
		return windDirection;
	}
	public String[] getConditionDescription() {
		return conditionDescription;
	}
	
	
	
	
	
	private static int myIntParser(String arg) throws MyException {
		int temp;
		try {
			temp = Integer.parseInt(arg);
		}
		catch (NumberFormatException e) {
			throw new MyException(arg, "integer");
		}
		return temp;
	}
	private static float myFloatParser(String arg) throws MyException {
		float temp;
		try {
			temp = Float.parseFloat(arg);
		}
		catch (NumberFormatException e) {
			throw new MyException(arg, "float");
		}
		return temp;
	}
	
	// Just don't want only white-space strings from being entered into description
	private static String myDescriptionParser(String arg) throws MyException{
		if (arg.trim().length() == 0) throw new MyException(arg, "string");
		return arg;
	}
}
	
