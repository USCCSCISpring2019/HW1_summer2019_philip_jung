package philipju_CSCI201L_Assignment1;
import java.util.ArrayList; // needed for ArrayList class
import java.util.Scanner;	// for Scanner class

public class Menu {
	Scanner keyboard;
	private ArrayList<City> cityList;
	City currentCity;
	boolean exitFlag;
	boolean allFlag;
	
	
	public Menu(ArrayList<City> cityList) {
		keyboard = new Scanner(System.in);
		this.cityList = cityList;
		currentCity = null;
		exitFlag = false;
		allFlag = true;
		
	}
	public void run() {
		do {
			if (selectCity()) {
				displayScreen();
				
				String userInput;
				do {
					System.out.print("What information would you like to know? ");
					userInput = keyboard.nextLine();
					int selectedOption;
					try {
						selectedOption = optionCheck(userInput);
						switch (selectedOption) {
							case 1:
								System.out.println("");
								selectTemperature();
								System.out.println("");
								break;
							case 2:
								System.out.println("");
								selectHighAndLow();
								System.out.println("");
								break;
							case 3:
								System.out.println("");
								selectHumidity();
								System.out.println("");
								break;
							case 4:
								System.out.println("");
								selectPressure();
								System.out.println("");
								break;
							case 5:
								System.out.println("");
								selectVisibility();
								System.out.println("");
								break;
							case 6:
								System.out.println("");
								selectWindspeedAndDirection();
								System.out.println("");
								break;
							case 7:
								System.out.println("");
								selectDescriptions();
								System.out.println("");
								break;
							case 8:
								selectEverything();
								break;
							case 9:
								System.out.println("");
								// Just continue down without executing any code
								// to break out of the while-loop.
								break;
						}
					}
					catch (MyException e) {
						System.out.println("That is not a valid option.");
					}
				} while (!userInput.equals("9"));
				

			}
		} while (exitFlag == false);
		
		// if exiting, close the I/O object
		System.out.println("Thank you for using my weather program.");
		keyboard.close();
	}
	private void displayScreen() {
		System.out.println("");
		System.out.println("\t1) Temperature");
		System.out.println("\t2) High and low temperature today");
		System.out.println("\t3) Humidity");
		System.out.println("\t4) Pressure");
		System.out.println("\t5) Visibility");
		System.out.println("\t6) Wind speed and direction");
		System.out.println("\t7) Descriptions of weather conditions");
		System.out.println("\t8) Everything");
		System.out.println("\t9) Enter a different city");
		System.out.println("");
		
	}
	private void selectTemperature() {
		if (!allFlag) {
			//The temperature in Los Angeles is 68 degrees Fahrenheit.
			System.out.println("The temperature in " + currentCity.getCity() +
							   " is " + currentCity.getCurrentTemperature() +
							   " degrees Fahrenheit.");
		}
		else {
			for (City curr : cityList) {
				System.out.println("The temperature in " + curr.getCity() +
						   " is " + curr.getCurrentTemperature() +
						   " degrees Fahrenheit.");
			}
		}
		
	}
	private void selectHighAndLow() {
		if (!allFlag) {
			//The high temperature in Los Angeles is 72 degrees Fahrenheit.
			//The low temperature in Los Angeles is 54 degrees Fahrenheit.
			System.out.println("The high temperature in " + currentCity.getCity() +
							   " is " + currentCity.getDayHigh() + " degrees Fahrenheit.");
			System.out.println("The low temperature in " + currentCity.getCity() +
					   " is " + currentCity.getDayLow() + " degrees Fahrenheit.");
		}
		else {
			for (City curr : cityList) {
				System.out.println("The high temperature in " + curr.getCity() +
						   " is " + curr.getDayHigh() + " degrees Fahrenheit.");
				System.out.println("The low temperature in " + curr.getCity() +
				   " is " + curr.getDayLow() + " degrees Fahrenheit.");
			}
		}
	}
	private void selectHumidity() {
		if (!allFlag) {
			//The humidity in Los Angeles is 35%.
			System.out.println("The humidity in " + currentCity.getCity() + " is " + currentCity.getHumidity() + "%.");
		} else {
			for (City curr : cityList) {
				System.out.println("The humidity in " + curr.getCity() + " is " + curr.getHumidity() + "%.");
			}
		}
	}
	private void selectPressure() {
		if (!allFlag) {
			//The pressure in Los Angeles is 29.80 Inch Hg.
			System.out.printf("The pressure in %s is %.2f Inch Hg.\n", currentCity.getCity(), currentCity.getPressure());
		} else {
			for (City curr : cityList) {
				System.out.printf("The pressure in %s is %.2f Inch Hg.\n", curr.getCity(), curr.getPressure());
			}
		}
	}
	private void selectVisibility() {
		if (!allFlag) {
			//The visibility in Los Angeles is 88.3 miles.
			System.out.println("The visibility in " + currentCity.getCity() + " is " + currentCity.getVisibility() + " miles.");
		} else {
			for (City curr : cityList) {
				System.out.println("The visibility in " + curr.getCity() + " is " + curr.getVisibility() + " miles.");
			}
		}
	}
	private void selectWindspeedAndDirection() {
		if (!allFlag) {
			//The wind speed in Los Angeles is 8.4 miles/hour.
			//The wind direction in Los Angeles is 270 degrees.
			System.out.println("The wind speed in " + currentCity.getCity() + " is " + currentCity.getWindspeed() + " miles/hour.");
			System.out.println("The wind direction in " + currentCity.getCity() + " is " + currentCity.getWindDirection() + " degrees.");
		} else {
			for (City curr : cityList) {
				System.out.println("The wind speed in " + curr.getCity() + " is " + curr.getWindspeed() + " miles/hour.");
				System.out.println("The wind direction in " + curr.getCity() + " is " + curr.getWindDirection() + " degrees.");
			}
		}
	}
	private void selectDescriptions() {
		if (!allFlag) {
			String[] temp = currentCity.getConditionDescription();
			System.out.print(currentCity.getCity() + " weather can be described as " + temp[0]);
			if (temp.length == 1) {
				System.out.println(".");
			}
			else if (temp.length == 2) {
				System.out.println(" and " + temp[1] + ".");
			}
			else {
				for (int i = 1; i < temp.length -1; i++) {
					System.out.print(", " + temp[i]);
				}
				System.out.println(", and " + temp[temp.length-1] + ".");
			}
			
		} else {
			for (City curr : cityList) {
				String[] temp = curr.getConditionDescription();
				System.out.print(curr.getCity() + " weather can be described as " + temp[0]);
				if (temp.length == 1) {
					System.out.println(".");
				}
				else if (temp.length == 2) {
					System.out.println(" and " + temp[1] + ".");
				}
				else {
					for (int i = 1; i < temp.length -1; i++) {
						System.out.print(", " + temp[i]);
					}
					System.out.println(", and " + temp[temp.length-1] + ".");
				}
			}
		}
	}
	private void selectEverything() {
		
		if (!allFlag) {
			System.out.println("");
			selectTemperature();
			selectHighAndLow();
			selectHumidity();
			selectPressure();
			selectVisibility();
			selectWindspeedAndDirection();
			selectDescriptions();
			System.out.println("");
		}
		else {
			// If allFlag is currently set
			// I would not want to repeat everything for each option
			// So first set the flag to false, then call all of the functions
			allFlag = false;
			for (City curr : cityList) {
				System.out.println("");
				currentCity = curr;
				selectTemperature();
				selectHighAndLow();
				selectHumidity();
				selectPressure();
				selectVisibility();
				selectWindspeedAndDirection();
				selectDescriptions();
			}
			System.out.println("");
			//reset currCity to nothing (becuase of allFlag)
			currentCity = null;
			//reset allFlag
			allFlag = true;
		}
		
	}
	private boolean selectCity() {
		String userInput;
		System.out.print("For what city would you like weather information? ");
		userInput = keyboard.nextLine();
		System.out.println("");
		// First, check if user wanted to exit the program
		if (userInput.equalsIgnoreCase("exit")) {
			exitFlag = true;
			return false;
		// Second, check if user wants to see all the cities.
		} else if (userInput.equalsIgnoreCase("all")) {
			System.out.println("I do have information about the weather in all cities.");
			currentCity = null;
			allFlag = true;
			return true;
		}
		
		// Third, check for the city within cityList
		allFlag = false;
		for (int i = 0; i < cityList.size(); i++) {
			if (cityList.get(i).getCity().equalsIgnoreCase(userInput)) {
				// Found the city. Continue code here
				System.out.println("I do have information about the weather in Los Angeles.");
				currentCity = cityList.get(i);
				return true;
			}
		}
		// Could not find the city
		System.out.println("Unable to find city " + userInput + ".");
		System.out.println("");
		return false;
	}
	
	
	// This private function will make two checks
	// First, see if the input can be parsed into an integer
	// Second, see if the integer is between 1 and 9
	// If not, throw MyException's no-arg constructor
	private int optionCheck(String userInput) throws MyException {
		int temp;
		try {
			temp = Integer.parseInt(userInput);
			if (temp > 9 || temp < 1)
				throw new MyException();
		}
		catch (NumberFormatException e) {
			throw new MyException();
		}
		return temp;
	}
	

}
